# PURE HD AI — Phase 1

Aplikasi Android native (Kotlin, Jetpack Compose, Media3 Transformer) untuk meningkatkan kualitas video **100% offline**.

## Fitur Phase 1
- **AI Video Enhancer**: unsharp mask adaptif (edge-aware) + kontras, di GPU (GLSL).
- **AI Video Restoration**: denoise bilateral 3x3 + penajaman ringan.
- **AI Super Resolution**: skala 2x (dibatasi anggaran RAM) + penajaman adaptif.
- **Enhance Again**: hasil terakhir dipakai sebagai input pass berikutnya.
- **Optimasi RAM 8 GB**: `MemoryGuard` membatasi resolusi/bitrate output (maks 2160p pada 8 GB), `largeHeap`, pipeline streaming.
- Tanpa permission INTERNET, tanpa API berbayar. Hasil ke `Movies/PureHD` via MediaStore.

> Catatan jujur: Phase 1 memakai filter GPU klasik, **bukan** jaringan neural. Super resolution neural (Real-ESRGAN via ONNX/NCNN) masuk Phase 3, lihat `docs/ROADMAP.md`.

## Status verifikasi (jujur)
- Source sudah diaudit manual terhadap API Media3 1.4.1, Compose BOM 2024.09, AGP 8.5.2.
- **Belum pernah dikompilasi** di lingkungan audit (tanpa SDK/internet). Bukti build sebenarnya = run hijau GitHub Actions + APK artifact.
- Uji fungsional (video benar-benar ter-enhance) hanya bisa dilakukan di perangkat.

## Build APK
Butuh JDK 17 + Android SDK (platform 34).
```
./gradlew assembleDebug
# APK: app/build/outputs/apk/debug/app-debug.apk
```
Tanpa Android Studio: push proyek ke GitHub, workflow `.github/workflows/build-apk.yml` membangun APK dan menyediakannya sebagai artifact.

## Struktur
```
app/src/main/java/ai/purehd/
  domain/  model & mode
  engine/  VideoEnhancer (Transformer), EnhanceShader (GLSL), OutputStore
  ui/      Compose UI + ViewModel
  util/    MemoryGuard
```

## Cara push dari HP (Termux)
```
unzip PureHD-AI-Phase1-fixed.zip && cd PureHD-AI
git init -b main && git add . && git commit -m "Phase 1 fixed"
git remote add origin https://github.com/USERNAME/REPO.git
git push -u origin main
```
Lalu buka tab Actions di GitHub, tunggu job "Build APK", unduh artifact `PureHD-AI-debug-apk`.
Catatan: minSdk 29 (Android 10+).

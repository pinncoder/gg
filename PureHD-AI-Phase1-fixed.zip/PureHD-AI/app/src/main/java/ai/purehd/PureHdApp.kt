package ai.purehd

import android.app.Application

class PureHdApp : Application()

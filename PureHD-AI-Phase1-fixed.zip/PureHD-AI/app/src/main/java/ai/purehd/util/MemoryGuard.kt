package ai.purehd.util

import android.app.ActivityManager
import android.content.Context

/**
 * Penjaga RAM untuk perangkat 8 GB (juga aman untuk 4–6 GB).
 * Pipeline streaming Transformer hanya menahan beberapa frame sekaligus, jadi
 * yang perlu dibatasi adalah resolusi output (ukuran buffer frame & encoder).
 */
object MemoryGuard {
    data class Budget(val maxOutputHeight: Int, val bitrateCap: Int, val totalGb: Double)

    fun budget(context: Context): Budget {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val totalGb = mi.totalMem / 1024.0 / 1024.0 / 1024.0
        val availGb = mi.availMem / 1024.0 / 1024.0 / 1024.0
        val maxH = when {
            totalGb >= 7.0 && availGb >= 2.0 -> 2160
            totalGb >= 5.0 && availGb >= 1.2 -> 1440
            else -> 1080
        }
        val bitrate = when (maxH) { 2160 -> 35_000_000; 1440 -> 20_000_000; else -> 12_000_000 }
        return Budget(maxH, bitrate, totalGb)
    }

    fun isLowMemory(context: Context): Boolean {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        return ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }.lowMemory
    }
}

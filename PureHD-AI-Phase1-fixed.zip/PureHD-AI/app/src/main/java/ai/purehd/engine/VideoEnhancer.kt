package ai.purehd.engine

import ai.purehd.domain.EnhanceMode
import ai.purehd.domain.EnhanceSettings
import ai.purehd.domain.VideoInfo
import ai.purehd.util.MemoryGuard
import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.annotation.OptIn
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Contrast
import androidx.media3.effect.Presentation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import java.io.File

/** Pemroses video offline berbasis Media3 Transformer + efek GPU. Harus dipanggil dari main thread. */
@OptIn(UnstableApi::class)
class VideoEnhancer(private val context: Context) {

    private var transformer: Transformer? = null
    private val main = Handler(Looper.getMainLooper())
    private var poller: Runnable? = null

    fun probe(uri: Uri): VideoInfo {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(context, uri)
            fun i(k: Int) = r.extractMetadata(k)?.toIntOrNull() ?: 0
            val rot = i(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)
            var w = i(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
            var h = i(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
            if (rot == 90 || rot == 270) { val t = w; w = h; h = t }
            val d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            return VideoInfo(uri, w, h, d)
        } finally { r.release() }
    }

    fun start(
        input: VideoInfo,
        settings: EnhanceSettings,
        output: File,
        onProgress: (Float) -> Unit,
        onDone: () -> Unit,
        onError: (String) -> Unit
    ) {
        cancel() // pastikan tidak ada job lama yang masih berjalan
        val reportError: (String) -> Unit = onError
        val reportDone: () -> Unit = onDone
        val reportProgress: (Float) -> Unit = onProgress
        val budget = MemoryGuard.budget(context)
        val k = settings.strength.factor
        val effects = mutableListOf<Effect>()

        // Super Resolution: skala 2x, dibatasi anggaran RAM.
        if (settings.mode == EnhanceMode.SUPER_RESOLUTION) {
            val wanted = settings.targetHeight ?: (input.height * 2)
            val h = wanted.coerceAtMost(budget.maxOutputHeight).coerceAtLeast(input.height)
            effects += Presentation.createForHeight(h)
        }
        when (settings.mode) {
            EnhanceMode.ENHANCER -> {
                effects += EnhanceEffect(sharpen = 0.8f * k, denoise = 0.0f)
                effects += Contrast(0.08f * k)
            }
            EnhanceMode.RESTORATION ->
                effects += EnhanceEffect(sharpen = 0.5f * k, denoise = (0.6f * k).coerceAtMost(1f))
            EnhanceMode.SUPER_RESOLUTION ->
                effects += EnhanceEffect(sharpen = 1.0f * k, denoise = (0.25f * k).coerceAtMost(1f))
        }

        val item = EditedMediaItem.Builder(MediaItem.fromUri(input.uri))
            .setEffects(Effects(emptyList<AudioProcessor>(), effects))
            .build()

        val encoder = DefaultEncoderFactory.Builder(context)
            .setRequestedVideoEncoderSettings(
                VideoEncoderSettings.Builder().setBitrate(budget.bitrateCap).build()
            ).build()

        val t = Transformer.Builder(context)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setEncoderFactory(encoder)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    stopPolling(); reportProgress(1f); reportDone()
                }
                override fun onError(composition: Composition, exportResult: ExportResult, e: ExportException) {
                    stopPolling(); reportError(e.message ?: "Gagal memproses video (${e.errorCodeName})")
                }
            })
            .build()
        transformer = t
        output.parentFile?.mkdirs(); if (output.exists()) output.delete()
        try {
            t.start(item, output.absolutePath)
        } catch (e: Exception) {
            transformer = null
            reportError("Gagal memulai proses: ${e.message}")
            return
        }

        val holder = ProgressHolder()
        poller = object : Runnable {
            override fun run() {
                if (t.getProgress(holder) == Transformer.PROGRESS_STATE_AVAILABLE) reportProgress(holder.progress / 100f)
                main.postDelayed(this, 400)
            }
        }.also { main.postDelayed(it, 400) }
    }

    fun cancel() { stopPolling(); transformer?.cancel(); transformer = null }

    private fun stopPolling() { poller?.let { main.removeCallbacks(it) }; poller = null }
}

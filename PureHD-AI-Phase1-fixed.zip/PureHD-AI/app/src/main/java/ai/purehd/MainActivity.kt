package ai.purehd

import ai.purehd.ui.HomeScreen
import ai.purehd.ui.theme.PureHdTheme
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { PureHdTheme { HomeScreen() } }
    }
}

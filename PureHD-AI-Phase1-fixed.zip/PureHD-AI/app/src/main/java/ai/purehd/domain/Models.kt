package ai.purehd.domain

import android.net.Uri

/** Mode pemrosesan. Phase 1 = pipeline GPU (OpenGL). Phase 2+ menambah model neural (ONNX/NCNN). */
enum class EnhanceMode(val title: String, val subtitle: String) {
    ENHANCER("AI Video Enhancer", "Ketajaman, kontras & warna lebih hidup"),
    RESTORATION("AI Video Restoration", "Kurangi noise & artefak kompresi lalu pertajam"),
    SUPER_RESOLUTION("AI Super Resolution", "Naikkan resolusi 2x dengan penajaman adaptif")
}

enum class Strength(val label: String, val factor: Float) {
    LIGHT("Ringan", 0.5f), BALANCED("Seimbang", 1.0f), STRONG("Kuat", 1.6f)
}

data class EnhanceSettings(
    val mode: EnhanceMode = EnhanceMode.ENHANCER,
    val strength: Strength = Strength.BALANCED,
    val targetHeight: Int? = null // null = otomatis
)

data class VideoInfo(val uri: Uri, val width: Int, val height: Int, val durationMs: Long)

sealed interface JobState {
    data object Idle : JobState
    data class Running(val progress: Float) : JobState
    data class Done(val output: Uri, val passes: Int) : JobState
    data class Failed(val message: String) : JobState
}

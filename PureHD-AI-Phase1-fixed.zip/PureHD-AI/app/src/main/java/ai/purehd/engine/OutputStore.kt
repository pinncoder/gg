package ai.purehd.engine

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import java.io.File

/** Menyimpan hasil ke galeri (Movies/PureHD) tanpa permission storage (MediaStore, minSdk 29+). */
object OutputStore {
    fun workFile(context: Context, name: String) = File(context.cacheDir, "work/$name.mp4")

    /** Blocking (I/O besar): panggil dari background thread. Mengembalikan null bila gagal. */
    fun publish(context: Context, file: File, displayName: String): Uri? {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "$displayName.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/PureHD")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val uri = try {
            resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
        } catch (e: Exception) {
            null
        } ?: return null
        return try {
            val out = resolver.openOutputStream(uri) ?: throw java.io.IOException("openOutputStream null")
            out.use { o -> file.inputStream().use { it.copyTo(o) } }
            resolver.update(uri, ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }, null, null)
            uri
        } catch (e: Exception) {
            try { resolver.delete(uri, null, null) } catch (ignored: Exception) {}
            null
        }
    }
}

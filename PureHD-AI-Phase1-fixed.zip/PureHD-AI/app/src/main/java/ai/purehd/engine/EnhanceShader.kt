package ai.purehd.engine

import android.content.Context
import android.opengl.GLES20
import androidx.annotation.OptIn
import androidx.media3.common.VideoFrameProcessingException
import androidx.media3.common.util.GlProgram
import androidx.media3.common.util.GlUtil
import androidx.media3.common.util.Size
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BaseGlShaderProgram
import androidx.media3.effect.GlEffect
import androidx.media3.effect.GlShaderProgram

/**
 * Efek GPU kustom: denoise (bilateral 3x3 ringan) + unsharp mask adaptif (edge-aware).
 * Berjalan di GPU sehingga hemat RAM dan real-time-friendly.
 */
@OptIn(UnstableApi::class)
class EnhanceEffect(
    private val sharpen: Float,
    private val denoise: Float
) : GlEffect {
    override fun toGlShaderProgram(context: Context, useHdr: Boolean): GlShaderProgram =
        EnhanceShaderProgram(useHdr, sharpen, denoise)
}

@OptIn(UnstableApi::class)
private class EnhanceShaderProgram(
    useHdr: Boolean,
    private val sharpen: Float,
    private val denoise: Float
) : BaseGlShaderProgram(useHdr, 1) {

    private val program: GlProgram = try {
        GlProgram(VERTEX, FRAGMENT)
    } catch (e: GlUtil.GlException) {
        throw VideoFrameProcessingException(e)
    }

    init {
        try {
            program.setBufferAttribute(
                "aFramePosition",
                GlUtil.getNormalizedCoordinateBounds(),
                GlUtil.HOMOGENEOUS_COORDINATE_VECTOR_SIZE
            )
            val identity = GlUtil.create4x4IdentityMatrix()
            program.setFloatsUniform("uTransformationMatrix", identity)
            program.setFloatsUniform("uTexTransformationMatrix", identity)
            program.setFloatUniform("uSharpen", sharpen)
            program.setFloatUniform("uDenoise", denoise)
        } catch (e: GlUtil.GlException) {
            throw VideoFrameProcessingException(e)
        }
    }

    override fun configure(inputWidth: Int, inputHeight: Int): Size {
        try {
            program.setFloatsUniform("uTexel", floatArrayOf(1f / inputWidth, 1f / inputHeight))
        } catch (e: GlUtil.GlException) {
            throw VideoFrameProcessingException(e)
        }
        return Size(inputWidth, inputHeight)
    }

    override fun drawFrame(inputTexId: Int, presentationTimeUs: Long) {
        try {
            program.use()
            program.setSamplerTexIdUniform("uTexSampler", inputTexId, 0)
            program.bindAttributesAndUniforms()
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
            GlUtil.checkGlError()
        } catch (e: GlUtil.GlException) {
            throw VideoFrameProcessingException(e, presentationTimeUs)
        }
    }

    override fun release() {
        super.release()
        try { program.delete() } catch (e: GlUtil.GlException) { throw VideoFrameProcessingException(e) }
    }

    companion object {
        private const val VERTEX = """
attribute vec4 aFramePosition;
uniform mat4 uTransformationMatrix;
uniform mat4 uTexTransformationMatrix;
varying vec2 vTexCoord;
void main() {
  gl_Position = uTransformationMatrix * aFramePosition;
  vec4 t = uTexTransformationMatrix * vec4(aFramePosition.x * 0.5 + 0.5, aFramePosition.y * 0.5 + 0.5, 0.0, 1.0);
  vTexCoord = t.xy;
}
"""
        private const val FRAGMENT = """
precision highp float;
uniform sampler2D uTexSampler;
uniform vec2 uTexel;
uniform float uSharpen;
uniform float uDenoise;
varying vec2 vTexCoord;

vec3 tap(vec2 o) { return texture2D(uTexSampler, vTexCoord + o * uTexel).rgb; }
float luma(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }

void main() {
  vec3 c = tap(vec2(0.0));
  // --- Denoise: bilateral 3x3 (bobot turun bila selisih luma besar -> tepi terjaga)
  vec3 acc = c; float wsum = 1.0;
  if (uDenoise > 0.001) {
    float lc = luma(c);
    float sigma = 0.02 + 0.10 * uDenoise;
    for (int y = -1; y <= 1; y++) {
      for (int x = -1; x <= 1; x++) {
        if (x == 0 && y == 0) continue;
        vec3 s = tap(vec2(float(x), float(y)));
        float d = luma(s) - lc;
        float w = exp(-(d * d) / (2.0 * sigma * sigma));
        acc += s * w; wsum += w;
      }
    }
    c = mix(c, acc / wsum, clamp(uDenoise, 0.0, 1.0));
  }
  // --- Unsharp mask adaptif
  vec3 blur = (tap(vec2(-1.0, 0.0)) + tap(vec2(1.0, 0.0)) + tap(vec2(0.0, -1.0)) + tap(vec2(0.0, 1.0))) * 0.25;
  vec3 detail = c - blur;
  float edge = smoothstep(0.004, 0.06, abs(luma(detail)));   // hindari menguatkan noise halus
  c = c + detail * uSharpen * (0.4 + 0.6 * edge);
  gl_FragColor = vec4(clamp(c, 0.0, 1.0), 1.0);
}
"""
    }
}

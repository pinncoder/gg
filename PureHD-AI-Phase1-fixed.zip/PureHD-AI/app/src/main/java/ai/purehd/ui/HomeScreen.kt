package ai.purehd.ui

import ai.purehd.domain.*
import ai.purehd.ui.theme.Cyan
import ai.purehd.ui.theme.Violet
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(vm: MainViewModel = viewModel()) {
    val ui by vm.state.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { it?.let(vm::pick) }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("PURE ", fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                        Text("HD AI", fontWeight = FontWeight.Black, color = Cyan, letterSpacing = 2.sp)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { pad ->
        Column(
            Modifier.padding(pad).padding(horizontal = 16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            SourceCard(ui.source) {
                picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
            }

            Text("Mode AI", fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onBackground)
            EnhanceMode.entries.forEach { m ->
                ModeCard(m, selected = ui.settings.mode == m) { vm.setMode(m) }
            }

            Text("Kekuatan", fontWeight = FontWeight.SemiBold)
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                Strength.entries.forEachIndexed { i, s ->
                    SegmentedButton(
                        selected = ui.settings.strength == s,
                        onClick = { vm.setStrength(s) },
                        shape = SegmentedButtonDefaults.itemShape(i, Strength.entries.size)
                    ) { Text(s.label) }
                }
            }

            when (val j = ui.job) {
                is JobState.Running -> ProgressCard(j.progress, onCancel = vm::cancel)
                is JobState.Done -> ResultCard(j, onShare = {
                    ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                        type = "video/mp4"; putExtra(Intent.EXTRA_STREAM, j.output)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }, "Bagikan hasil"))
                }, onAgain = vm::enhanceAgain)
                is JobState.Failed -> ErrorCard(j.message, vm::dismissError)
                JobState.Idle -> Unit
            }

            val busy = ui.job is JobState.Running
            Button(
                onClick = vm::enhance,
                enabled = ui.source != null && !busy,
                modifier = Modifier.fillMaxWidth().height(56.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                Icon(Icons.Default.AutoAwesome, null); Spacer(Modifier.width(8.dp))
                Text("Mulai Enhance", fontWeight = FontWeight.Bold)
            }
            Text(
                "100% offline • tanpa API berbayar • hasil disimpan di Movies/PureHD",
                fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .6f)
            )
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun SourceCard(info: VideoInfo?, onPick: () -> Unit) {
    Card(
        Modifier.fillMaxWidth().clickable(onClick = onPick),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Box(
            Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Cyan.copy(.12f), Violet.copy(.12f)))).padding(24.dp)
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.VideoLibrary, null, tint = Cyan, modifier = Modifier.size(40.dp))
                Spacer(Modifier.height(8.dp))
                if (info == null) {
                    Text("Pilih video", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("Ketuk untuk memilih dari galeri", fontSize = 13.sp)
                } else {
                    Text("${info.width}×${info.height}", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    Text("${info.durationMs / 1000} detik • ketuk untuk ganti", fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
private fun ModeCard(mode: EnhanceMode, selected: Boolean, onClick: () -> Unit) {
    val icon = when (mode) {
        EnhanceMode.ENHANCER -> Icons.Default.AutoFixHigh
        EnhanceMode.RESTORATION -> Icons.Default.Healing
        EnhanceMode.SUPER_RESOLUTION -> Icons.Default.HighQuality
    }
    Card(
        Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(if (selected) 2.dp else 1.dp, if (selected) Cyan else MaterialTheme.colorScheme.surfaceVariant),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = if (selected) Cyan else Violet, modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(mode.title, fontWeight = FontWeight.Bold)
                Text(mode.subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(.65f))
            }
            RadioButton(selected, onClick)
        }
    }
}

@Composable
private fun ProgressCard(p: Float, onCancel: () -> Unit) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text("Memproses… ${(p * 100).toInt()}%", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(progress = { p }, modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)))
            TextButton(onClick = onCancel) { Text("Batalkan") }
        }
    }
}

@Composable
private fun ResultCard(j: JobState.Done, onShare: () -> Unit, onAgain: () -> Unit) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), border = BorderStroke(1.dp, Cyan)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.CheckCircle, null, tint = Cyan); Spacer(Modifier.width(8.dp))
                Text("Selesai (pass ke-${j.passes}) — tersimpan di Movies/PureHD", fontWeight = FontWeight.Bold)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onShare) { Icon(Icons.Default.Share, null); Spacer(Modifier.width(6.dp)); Text("Bagikan") }
                Button(onClick = onAgain) { Icon(Icons.Default.Replay, null); Spacer(Modifier.width(6.dp)); Text("Enhance Again") }
            }
        }
    }
}

@Composable
private fun ErrorCard(msg: String, onDismiss: () -> Unit) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
        Column(Modifier.padding(16.dp)) {
            Text(msg, color = MaterialTheme.colorScheme.onErrorContainer)
            TextButton(onClick = onDismiss) { Text("Tutup") }
        }
    }
}

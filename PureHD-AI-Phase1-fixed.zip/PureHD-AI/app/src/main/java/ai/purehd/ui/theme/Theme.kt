package ai.purehd.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Cyan = Color(0xFF22D3EE)
val Violet = Color(0xFFA78BFA)
val Ink = Color(0xFF0B0F14)
val Panel = Color(0xFF141A22)

private val Dark = darkColorScheme(
    primary = Cyan, secondary = Violet, background = Ink, surface = Panel,
    surfaceVariant = Color(0xFF1C2430), onPrimary = Ink, onBackground = Color(0xFFE6EDF3), onSurface = Color(0xFFE6EDF3)
)

@Composable
fun PureHdTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Dark, content = content)
}

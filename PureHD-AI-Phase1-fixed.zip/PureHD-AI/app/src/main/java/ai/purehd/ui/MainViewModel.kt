package ai.purehd.ui

import ai.purehd.domain.*
import ai.purehd.engine.OutputStore
import ai.purehd.engine.VideoEnhancer
import android.app.Application
import android.net.Uri
import androidx.core.net.toUri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import java.io.File

data class UiState(
    val source: VideoInfo? = null,
    val settings: EnhanceSettings = EnhanceSettings(),
    val job: JobState = JobState.Idle,
    val passes: Int = 0
)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val enhancer = VideoEnhancer(app)
    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state

    private var lastWorkFile: File? = null

    fun pick(uri: Uri) {
        runCatching { enhancer.probe(uri) }
            .onSuccess { info ->
                lastWorkFile = null
                _state.update { UiState(source = info, settings = it.settings) }
            }
            .onFailure { e -> _state.update { it.copy(job = JobState.Failed("Video tidak bisa dibaca: ${e.message}")) } }
    }

    fun setMode(m: EnhanceMode) = _state.update { it.copy(settings = it.settings.copy(mode = m)) }
    fun setStrength(s: Strength) = _state.update { it.copy(settings = it.settings.copy(strength = s)) }

    fun enhance() {
        val src = _state.value.source ?: return
        lastWorkFile = null
        startJob(src, 1)
    }

    /** Enhance Again: hasil terakhir dijadikan input baru. */
    fun enhanceAgain() {
        val f = lastWorkFile ?: return
        val info = runCatching { enhancer.probe(f.toUri()) }.getOrNull() ?: return
        startJob(info, _state.value.passes + 1)
    }

    private fun startJob(from: VideoInfo, passes: Int) {
        val ctx = getApplication<Application>()
        val out = OutputStore.workFile(ctx, "pass_$passes")
        _state.update { it.copy(job = JobState.Running(0f)) }
        enhancer.start(
            input = from,
            settings = _state.value.settings,
            output = out,
            onProgress = { p -> _state.update { it.copy(job = JobState.Running(p)) } },
            onDone = {
                // I/O besar dilakukan di background agar UI tidak macet (ANR).
                viewModelScope.launch {
                    val uri = withContext(Dispatchers.IO) {
                        OutputStore.publish(ctx, out, "PureHD_${System.currentTimeMillis()}_x$passes")
                    }
                    val previous = lastWorkFile
                    lastWorkFile = out // hasil pass ini jadi input untuk "Enhance Again"
                    if (previous != null && previous != out) withContext(Dispatchers.IO) { previous.delete() }
                    _state.update {
                        it.copy(
                            passes = passes,
                            job = if (uri != null) JobState.Done(uri, passes)
                            else JobState.Failed("Gagal menyimpan ke galeri")
                        )
                    }
                }
            },
            onError = { msg -> _state.update { it.copy(job = JobState.Failed(msg)) } }
        )
    }

    fun cancel() { enhancer.cancel(); _state.update { it.copy(job = JobState.Idle) } }
    fun dismissError() = _state.update { it.copy(job = JobState.Idle) }

    override fun onCleared() { enhancer.cancel() }
}

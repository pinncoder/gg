# Roadmap PURE HD AI

| Fase | Isi | Status |
|---|---|---|
| 1 | Arsitektur native, UI Compose, pipeline GPU offline (Enhancer / Restoration / Super Resolution), Enhance Again, MemoryGuard | **Kode selesai & diaudit; menunggu build CI + uji di perangkat** |
| 2 | Foreground service + antrean job, resume, notifikasi progres, preview before/after, pengaturan | Berikutnya |
| 3 | Inference neural on-device: Real-ESRGAN / SwinIR kecil via ONNX Runtime Mobile (NNAPI/GPU) atau NCNN-Vulkan, tiling untuk RAM 8 GB | Rencana |
| 4 | Model restorasi (denoise/deblock/deband), temporal consistency, frame interpolation opsional | Rencana |
| 5 | Optimasi (thermal, benchmark per perangkat), signing rilis, APK final + ZIP lengkap | Rencana |

Semua model yang dipakai harus berlisensi bebas (Apache/BSD/MIT) dan dibundel di APK: tanpa API berbayar, tanpa internet.
